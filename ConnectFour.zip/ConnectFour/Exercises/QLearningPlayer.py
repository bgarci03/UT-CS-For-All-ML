import pygame
import random
import argparse
from Helpers.Players import Player

# define some global variables
BLUE = (0, 0, 255)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BOARD_SIZE = (7,6)

class ColumnFullException(Exception):
    """An exception that will be thrown if a column of the board is full"""
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)

class QLearningPlayer(Player):
    """A class that represents an AI using Q-learning algorithm"""

    def __init__(self, coin_type, epsilon=0.2, alpha=0.3, gamma = 0.9):
        """
        Initialize a Q-learner with parameters epsilon, alpha and gamma
        and its coin type
        """
        Player.__init__(self, coin_type)
        self.qVals = {}
        self.epsilon = epsilon # e-greedy chance of random exploration
        self.alpha = alpha # learning rate
        self.discount = gamma


    def getQValue(self, state, action):
        """
          Returns the Q-value of the (state,action) pair if it is in the q-table.
          If we have never seen this (state,action) pair, add it to the q-table
          and initialize its qvalue to 0.
        """
        pass

    def getAction(self, state, legalActions):
        """
        Return an action based on the best move recommendation by the current
        Q-Table with a epsilon chance of trying out a new move
        """
        pass

    def update(self, state, action, nextState, reward):
        """
        Determine the reward based on its current chosen action and update
        the Q table using the reward recieved and the maximum future reward
        based on the resulting state due to the chosen action
        """
        pass
      
    def computeValueFromQValues(self, state, actions):
        """
          Returns max_action Q(state,action)
          where the max is over legal actions.  Note that if
          there are no legal actions, which is the case at the
          terminal state, you should return a value of 0.0.
        """
        pass

    def computeActionFromQValues(self, state, actions):
        """
          Compute the best action to take in a state.  Note that if there
          are no legal actions, which is the case at the terminal state,
          you should return None.
        """
        pass
