from dis import dis
from random import seed
from random import randrange


# Make a prediction with weights
def classify(row, weights):
    sum = weights[0]
    for i in range(len(row) - 1):
        sum += row[i] * weights[i + 1]
    
    if sum >= 0:
        return 1
    else:
        return 0
 
#Estimate Perceptron weights using stochastic gradient descent
def train(train_data, n_epoch, l_rate=1):
    weights = []
    for i in range(len(train_data[0])):
        weights.append(randrange(0, 100))
    
    for n in range(n_epoch):
        num_correct = 0
        for row in train_data:
            prediction = classify(row, weights)
            actual = row[-1]
            if prediction != actual:
                for i in range(1, len(weights)):
                    weights[i] = weights[i] + l_rate * ((actual-prediction) * row[i-1])
                weights[0] = weights[0] + l_rate * (actual - prediction)
            else:
                num_correct += 1
        print("epoch", n, "....", (num_correct/(len(train_data))) * 100, "% correct.")

def cross_validate(dataset, n_folds, n_epoch):
    size = len(dataset)//n_folds
    partition_start = 0
    partition_end = size

    percentages = []
    for reps in range(n_folds):
        # Training Phase
        weights = []
        for i in range(len(dataset[0])):
            weights.append(randrange(0, 1))

        test_data = dataset[partition_start:partition_end]

        if partition_end != len(dataset):
            train_data = dataset[partition_end:]
        if partition_start != 0:
            for i in range(partition_start):
                train_data.append(dataset[i])

        for i in range(n_epoch):
            for row in train_data:
                prediction = classify(row, weights)
                actual = row[-1]

                if prediction != actual:
                    for j in range(1, len(weights)):
                        weights[j] = weights[j] + (actual - prediction) * row[j - 1]
                    weights[0] = weights[0] * (actual - prediction)

        correct = 0
        for row in test_data:
            prediction = classify(row, weights)
            actual = row[-1]

            if prediction == actual:
                correct += 1      
        
        partition_start += size
        partition_end += size

        percentages.append(correct/len(test_data) * 100)
    avg_sum = sum(percentages)
    print("Mean Accuracy: ", str(avg_sum/n_folds) + "%")
