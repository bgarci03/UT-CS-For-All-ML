# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).
# ----------


# Perceptron implementation
import Helpers.util
from random import randrange


class PerceptronClassifier:

    def __init__(self, legalLabels, max_iterations):
        self.legalLabels = legalLabels
        self.type = "perceptron"
        self.epochs = max_iterations
        self.weights = None


    def classify(self, data):
        sums =  []

        for num_weights in self.weights:
            sum = 0
            for i in range(len(num_weights)):
                sum += data[i] * num_weights[i]
            sums.append(sum)
        
        return sums.index(max(sums))


 

    def train(self, train_data, labels):
        self.weights = []
        for i in range(10):
            add_weights = []
            for j in range(784):
                add_weights.append(randrange(0, 100))
            self.weights.append(add_weights)

        for i in range(self.epochs):
            correct = 0
            for row, actual in zip(train_data, labels):
                prediction = self.classify(row)
                
                if prediction != actual:
                    for x in range(len(self.weights[prediction])):
                        self.weights[prediction][x] = self.weights[prediction][x] - row[x]
                    for x in range(len(self.weights[actual])):
                        self.weights[actual][x] = self.weights[actual][x] + row[x]
                else:
                    correct += 1
                
                # print(prediction, actual)
            print("epoch " + str(i) + " .... " + str(correct/len(train_data) * 100) + "% correct.")
