from math import sqrt

def normalize_data(train, test):
    min_features = []
    max_features = []
    for i in range(len(train[0])):
        temp_features = []
        for point in train:
            temp_features.append(point[i])
        min_features.append(min(temp_features))
        max_features.append(max(temp_features))

    for data in train:
        for i in range(len(data)):
            data[i] = (data[i] - min_features[i]) / (max_features[i] - min_features[i])
    for data in test:
        for i in range(len(data)):
            data[i] = (data[i] - min_features[i]) / (max_features[i] - min_features[i])
    
    return train, test

def get_distances(point, data):
    distances = []

    for data_point in data:
        summation = 0
        for i in range(len(point)):
            summation += (point[i] - data_point[i])**2
        
        distances.append(sqrt(summation))
    return distances

def run_knn(train_set, test_set, k):
    normalize_data(train_set, test_set)

    predictions = []
    actual = []
    train_set_rm = []

    for point in train_set:
        train_set_rm.append(point[:len(point)])
    for point in test_set:
        actual.append(int(point[-1]))

    for record in test_set:
        distances = get_distances(record[:len(record)], train_set_rm)

        k_nearest_neighbors = sorted(range(0, len(train_set)), key=(lambda index: distances[index]))[:k]

        count_0 = 0
        count_1 = 0

        for neighbor in k_nearest_neighbors:
            if train_set[neighbor][-1] == 0:
                count_0 += 1
            else:
                count_1 += 1
        
        if count_0 > count_1:
            predictions.append(0)
        else:
            predictions.append(1)

    return predictions, actual

def run_CV(data, k=3, folds=5):
    size = len(data)//folds
    partition_start = 0
    partition_end = size

    avg_sum = 0
    # ensure = []

    for _ in range(folds):
        test_data = data[partition_start:partition_end]
        train_data = data[partition_end:] + data[:partition_start]
    
        if len(data) % folds != 0:
            for i in range(len(data) % folds):
                train_data.append(data[-i])

        # DEBUG CODE
        # if train_data in ensure:
        #     print("FIXME ------")
        # ensure.append(train_data)

        predictions, actual = run_knn(train_data, test_data, k)

        correct = 0
        for pred, act in zip(predictions, actual):
            if pred == act:
                correct += 1
        
        avg_sum += correct/len(predictions)

        partition_start += size
        partition_end += size

        print("FOLD", _, "-----")
        print("PREDICTION :", predictions[:10])
        print("ACTUAL     :", actual[:10])

    return avg_sum/folds
