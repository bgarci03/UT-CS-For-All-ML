student_name = "Brandon"

print("Each morning", student_name, "biked through the vibrant UT campus.")
