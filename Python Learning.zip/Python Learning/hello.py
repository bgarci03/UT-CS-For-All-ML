#print("Hello Neel and Brandon")
#print("Burnt orange and white,")
#print("Longhorns stand with pride and might,")
#print("Hook em, Texas fight!")
print("")
print("""  @..@ 

 (----)

(>____<)

^^~~~~^^    """)