sum = 0
for i in range(1, 98, 2):
    sum += i/(i+2)
print(round(sum, 3))