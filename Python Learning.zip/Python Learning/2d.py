lst = [ [1,2,3], 

 [4,5,6], 

 [7,8,9] ]

print(lst[2][1])


rooms = [[100, 101, 102, 103, 104],
    [200, 201, 202, 203, 204],
    [300, 301, 302, 303, 304],
    [400, 401, 402, 403, 404]
]

rooms1 = [["available", "available", "available", "Angie - 103", "Brian"],
    ["Claire", "available", "available", "available", "available"],
    ["available", "available", "David", "available", "available"],
    ["available", "Emily - 401", "available", "available", "available"]
]


print(rooms1[3][1])
print(rooms1[1][4])
rooms1[2][3] = "Frank - 303"