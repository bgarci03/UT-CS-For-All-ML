# num1 = 9
# num2 = 2

# print(num2 <= num1)

# num3 = 8
# num4 = 8

# print(num3 != num4)


def payamount(hours, pay):
    if hours <= 40:
        return hours * pay
    else:
        if hours > 55:
            print("Too many hours worked!")
        return hours * pay + 100

print(payamount(56, 1))