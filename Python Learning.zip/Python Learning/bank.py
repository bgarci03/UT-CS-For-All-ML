class BankAccount:

   def __init__(self, name, account_number):

       self.name = name

       self.account_number = account_number

       self.balance = 0

   def deposit(self, amount):

       self.balance += amount

  

   def withdraw(self, amount):
        if (self.balance - amount) >= 0:
           self.balance -= amount
        else:
            print("insufficient funds")

angie_acct = BankAccount("angie", 1234)
angie_acct.deposit(200)
angie_acct.withdraw(300)