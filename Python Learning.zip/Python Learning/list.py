list1 = [1, 4, 9, 5]
list2 = ["red", "green", "blue"]
list3 = [2, "hello", 3.5, 8]

#print(list3[2])
#print(list1[0])
#print(list2[2])

def get(lst, index, string):
    lst[index] = string

decoy = [1, 2, 3, 4]
get(decoy, 2, "hello")
print(decoy)