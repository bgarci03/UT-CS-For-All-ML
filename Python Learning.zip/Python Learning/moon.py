#person_weight = 100
#moon_weight = person_weight * 0.1654
#print("Earth Weight:", person_weight)
#print("Moon Weight:", moon_weight)

def moon_weight(earth_weight):
    return "Your moon weight is " + str(earth_weight * 0.1654) + " lbs"

print(moon_weight(150))

def triangle_area(base, height):
    return base * height * (1/2)

print(triangle_area(7, 8))