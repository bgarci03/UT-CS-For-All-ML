


def say_hello(name):
    print("Hello", name, "!!!")


say_hello("Neel")
say_hello("Bob")
say_hello("john")