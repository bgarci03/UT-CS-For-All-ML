
# # #for i in range(5):
# #  #   print(i)


# # def loop(start, end):
# #     if (start > end):
# #         print("range error")
# #     else:
# #         for i in range(start, end):
# #             print(i)

# # loop(8, 1)
# # loop(7, 10)

# def double(thing):
#     new = []
#     for n in thing:
#         d = n * 2
#         new.append(d)
#     return new

# print(double([1, 2, 3, 4]))


def items(thing):
    y = 0
    for x in thing:
        print(y, x)
        y += 1

items(["red", "blue", "green"])