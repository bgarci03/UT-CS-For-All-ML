# 
# thing = [1,2,3,4]
# i = 0
# sum = 0
# while i < len(thing):
    # sum += thing[i]
    # i = i+1
# 
# print(sum)
# thing = [1,2,3,4]
# i = 0

# index = 0
# while index < len(thingy):
    # if (thingy[index] > 0):
        # sum += thingy[index]
    # index += 1

# thingy = [1, -2, 3, 4]
# sum = 0
# for i in thingy:
#     if i > 0:
#         sum += i
# print(sum)

for i in range(2, 5):
    for j in range(1, 6):
        print(i, '*', j, '=', i * j)
    print()