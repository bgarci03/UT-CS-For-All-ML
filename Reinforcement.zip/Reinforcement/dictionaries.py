student_scores = {"Alice": 85, "Bob": 92, "Charlie": 78, "Dana": 82, "Emily": 95}

# Task 1.1
student_names = ["Alice", "Brian", "Charlie", "David", "Emily", "Fred"]

for name in student_names:
    if name in student_scores:
        print(name, student_scores[name])
    else:
        student_scores[name] = 0
        print(name, "added")

print(student_scores)

# Task 1.2
print(student_scores["Bob"])
student_scores["Charlie"] = 85