import pygame
import random
import argparse
from Helpers.Players import Player

# define some global variables
BLUE = (0, 0, 255)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BOARD_SIZE = (7,6)

class ColumnFullException(Exception):
    """An exception that will be thrown if a column of the board is full"""
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)

class QLearningPlayer(Player):
    """A class that represents an AI using Q-learning algorithm"""

    def __init__(self, coin_type, epsilon=0.2, alpha=0.3, gamma = 0.9):
        """
        Initialize a Q-learner with parameters epsilon, alpha and gamma
        and its coin type
        """
        Player.__init__(self, coin_type)
        self.qVals = {}
        self.epsilon = epsilon # e-greedy chance of random exploration
        self.alpha = alpha # learning rate
        self.discount = gamma


    def getQValue(self, state, action):
        """
          Returns the Q-value of the (state,action) pair if it is in the q-table.
          If we have never seen this (state,action) pair, add it to the q-table
          and initialize its qvalue to 0.
        """
        #action = action.capitalize()

        if state in self.qVals:
            if action in self.qVals[state]:
                return self.qVals[state][action]
            else:
              self.qVals[state][action] = 0
              return 0

            
        print(state)
        print(action)
        self.qVals[state] = {}
        self.qVals[state][action] = 0
        return 0


    def getAction(self, state, legalActions):
        """
        Return an action based on the best move recommendation by the current
        Q-Table with a epsilon chance of trying out a new move
        """
        legalactions = legalActions
        action = None
        print("legal actions", legalactions)
        "*** YOUR CODE HERE ***"
        chance = random.random() < self.epsilon
        if (len(legalactions) == 0):
          return None

        if chance:
          action = random.choice(legalactions)
        else:
          action = self.computeActionFromQValues(state, legalactions)

        
        return action

    def update(self, state, action, nextState, reward):
        """
        Determine the reward based on its current chosen action and update
        the Q table using the reward recieved and the maximum future reward
        based on the resulting state due to the chosen action
        """

        #action = action.capitalize()

        currQ = self.getQValue(state, action)
        
        self.qVals[state][action] = currQ + self.alpha * (reward + self.discount * self.computeValueFromQValues(nextState, [action]) - currQ)
      
    def computeValueFromQValues(self, state, actions):
        """
          Returns max_action Q(state,action)
          where the max is over legal actions.  Note that if
          there are no legal actions, which is the case at the
          terminal state, you should return a value of 0.0.
        """
        if len(actions) <= 0:
          return 0
        return self.getQValue(state, self.computeActionFromQValues(state, actions))

    def computeActionFromQValues(self, state, actions):
        """
          Compute the best action to take in a state.  Note that if there
          are no legal actions, which is the case at the terminal state,
          you should return None.
        """
        legal_actions = actions

        most = 0
        best = None
        if (len(legal_actions) > 0):
          most = self.getQValue(state, legal_actions[0])
          best = legal_actions[0]

        for action in legal_actions:
          if (self.getQValue(state, action) > most):
            most = self.getQValue(state, action)
            best = action

        return best
